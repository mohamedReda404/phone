package com.example.nayapay_clone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}

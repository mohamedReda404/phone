package com.example.nayapayclone

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
